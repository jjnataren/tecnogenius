package mentoring.com.mx.holamundosqlite;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import mentoring.com.mx.holamundosqlite.bd.BaseDAO;
import mentoring.com.mx.holamundosqlite.bd.CreaBaseDatos;


public class HolaMundoSQLite extends ActionBarActivity {

    private BaseDAO baseDAO;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hola_mundo_sqlite);
        baseDAO = new BaseDAO();
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_hola_mundo_sqlite, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
    public void clicSaludar(View view){

        // obtenemos una referencia del TextView que se encuentra debajo del boton
        TextView textView = (TextView) this.findViewById(R.id.editText);
        TextView textViewDisplay = (TextView) this.findViewById(R.id.textView);

        // si la base se creó correctamente insertamos en ella y luego extraemos los datos
        // para mostrarlos en el la pantalla
        if(baseDAO.crearBDSQLite(this)){
            // método que realiza la llamada a las clases que permiten realizar la inserción
            // de datos utilizan SQLite
            baseDAO.insertarEnBD(textView.getText().toString());

            // una vez insertados los datos los leemos y los mostramos en pantalla
            textViewDisplay.setText(baseDAO.leerDeBD());

        }else{
            textViewDisplay.setText("No se pudo crear la BD correctamente...");
        }
        baseDAO.closeBD();
    }
}