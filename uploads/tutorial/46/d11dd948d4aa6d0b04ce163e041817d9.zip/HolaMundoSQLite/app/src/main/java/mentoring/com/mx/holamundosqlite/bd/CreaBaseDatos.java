package mentoring.com.mx.holamundosqlite.bd;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

/**
 * Created by Miguel Angel on 06/04/2015.
 */
public class CreaBaseDatos extends SQLiteOpenHelper {

    // declaramos una constante donde almacenamos el nombre de la base de datos
    // agregamos la extension .db por legibilidad y entendimiento pero no es obligatorio
    // es decir se puede crear el archivo sin especificar la extension
    public static final String NOMBRE_BASEDATOS = "holamundo.db";

    // version de base de datos
    public static final int VERSION_BASEDATOS=1;

    // nombre de la tabla
    public static final String NOMBRE_TABLA ="NOMBRES";

    // sintaxis para crear la base de datos que almacenara el dato ingresado en la pantalla
    public static final String
            TABLA_GENERADA = "CREATE TABLE "+NOMBRE_TABLA+"(NOMBRE_ID INTEGER PRIMARY KEY AUTOINCREMENT, " +
                                                 "NOMBRE TEXT);";
    public CreaBaseDatos(Context context) {
        super(context, NOMBRE_BASEDATOS, null, VERSION_BASEDATOS);
    }

    /**
     *@menthod onCreate  método invocado automaticamente por Android, este método no se debe invocar
     * manualmente. onCreate se invocara siempre que se genere una instancia de CreaBaseDatos y aqui
     * se debe agregar el código para crear las tablas de la base de datos.
     * @param db
     */

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(TABLA_GENERADA);
        Log.i("SQLITE_SAMPLE","Tabla creada...");
    }
    /**
     *@menthod onUpgrade método invocado automaticamente por Android, este método no se debe invocar
     * manualmente. onUpgrade se invocara siempre que se genere una nueva version de la base de datos
     * existente..
     * @param db
     * @param oldVersion  parametro que indica la version de la base de datos existente.
     * @param newVersion parametro que indica la nueva version a la cual se debe actualizar la base
     *                   de datos existente
     */
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " +NOMBRE_TABLA );
        onCreate(db);
        Log.i("SQLITE_SAMPLE","base de datos actualizada correctamente...");
    }
}