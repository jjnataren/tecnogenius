package mentoring.com.mx.holamundosqlite.bd;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

/**
 * Created by Miguel Angel on 17/04/2015.
 */
public class BaseDAO {
    private CreaBaseDatos creaBaseDatos;
    private SQLiteDatabase sqLiteDatabase;

    public boolean crearBDSQLite(Context context){
        creaBaseDatos = new CreaBaseDatos(context);
        sqLiteDatabase = creaBaseDatos.getWritableDatabase();
        return sqLiteDatabase != null;
    }

    public String leerDeBD() {
        String[] cols = {"NOMBRE"};
        Cursor query = sqLiteDatabase.query(CreaBaseDatos.NOMBRE_TABLA, cols, null, null, null, null,null);
        String result = "";
        if(query.getCount() > 0)
        {while (query.moveToNext()){
            result = query.getString(query.getColumnIndex("NOMBRE"));
        }
        }
        return result;
    }

    public long  insertarEnBD(String text){
        ContentValues contentValues = new ContentValues();
        contentValues.put("NOMBRE",text);
        long pkValue = sqLiteDatabase.insert(CreaBaseDatos.NOMBRE_TABLA,null,contentValues);
        return pkValue;
    }

    public void closeBD(){
        if(sqLiteDatabase != null) {
            sqLiteDatabase.close();
        }
    }
}
