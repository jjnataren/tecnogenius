public class TestMultidimensionalArray {

	public static void main(String[] args) {

		// creamos una arreglo bidimensional que almacenara elementos de tipo
		// entero (int)
		int[][] coordenadas = new int[3][];

		// en cada fila indicamos que vivira un arreglo de tres posiciones de
		// tipo int
		coordenadas[0] = new int[3];
		coordenadas[1] = new int[3];
		coordenadas[2] = new int[3];

		// llenamos el arreglo bidimensional accediendo a
		// cada una de sus posiciones por medio de sus indices
		coordenadas[0][0] = 1;
		coordenadas[0][1] = 2;
		coordenadas[0][2] = 3;
		coordenadas[1][0] = 4;
		coordenadas[1][1] = 5;
		coordenadas[1][2] = 6;
		coordenadas[2][0] = 7;
		coordenadas[2][1] = 8;
		coordenadas[2][2] = 9;

		// si queremos obtener el valor 7 que esta almacenado en nuestro arreglo
		// podriamos acceder a el mediante sus indices

		for (int i = 0; i < coordenadas.length; i++) {
			for (int j = 0; j < coordenadas.length; j++) {
				System.out.print(" "+coordenadas[i][j]);
			}
			System.out.println();
		}
	}
}