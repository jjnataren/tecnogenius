package sentenciaif;

public class SentenciaIF {

	public static void main(String[] args) {

		// definicion de variables
		int a;
		int b;

		// asignacion de valores
		a = 10;
		b = 15;

		/*
		 * evaluamos una condicion y almacenamos el valor en una variable
		 * llamada 'condition', las condiciones siempre regresan un valor
		 * boolean (true o false)
		 */
		boolean condition = a > b;

		if (condition) {
			System.out.println("El valor de 'a' es mayor que el de 'b'.");
		}

		System.out.println("Fin de ejecucion del programa.");
	}
}