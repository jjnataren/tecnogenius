package mx.com.mentoring.impl;

import mx.com.mentoring.IVolador;

public class GloboAerostatico implements IVolador {

	private void aumentarAireCaliente() {
			System.out.println(" aumentando induccion de aire caliente en el globo...");
	}

	private void soltarAncla() {
			System.out.println(" presion alcanzada, soltando anclas...");
	}

	private void anclar() {
			System.out.println("  . . . anclando globo aerostatico");
	}

	private void disminuirAireCaliente() {
		System.out.println("  . . . liberando aire caliente");
	}

	public void aterrizar() {
		System.out.println(" . . . bajando globo a 20 nudos por hora");
		anclar();
	}

	public void despegar() {
		aumentarAireCaliente();
		soltarAncla();
	}

	public void acelerar() {
		System.out.println(" acelerando, altura alcanzada...");
		aumentarAireCaliente();
	}

	public void desacelerar() {
		System.out.println(" . . . interrumpir induccion de aire caliente");
		disminuirAireCaliente();
	}

	public void encender() {
		System.out.println("iniciando encendido flama para globo aerostatico...");
	}

	public void apagar() {
		System.out.println(" . . . apagando flama de globo aerostatico");
	}
}