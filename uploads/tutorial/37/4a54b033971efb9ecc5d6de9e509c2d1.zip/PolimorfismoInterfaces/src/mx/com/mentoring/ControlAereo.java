package mx.com.mentoring;

import java.util.ArrayList;

import mx.com.mentoring.impl.Boeing747;
import mx.com.mentoring.impl.GloboAerostatico;
import mx.com.mentoring.impl.Helicoptero;

public class ControlAereo {

	public static void main(String args[]) {
		// creamos un arreglo que contenga a todos nuestros objetos voladores
		ArrayList<IVolador> objetosVoladores = new ArrayList<IVolador>();

		// creamos un helicoptero
		Helicoptero helicoptero = new Helicoptero();

		// creamos un avion Boeing747
		Boeing747 avion = new Boeing747();

		// creamos un globo aerostatico
		GloboAerostatico globo = new GloboAerostatico();

		// agregamos todos nuestros objetos a nuestro arreglo de objetos voladores
		objetosVoladores.add(helicoptero);
		objetosVoladores.add(avion);
		objetosVoladores.add(globo);

		// ponemos a nuestros objetos voladores en espacio aereo
		for (IVolador iVolador : objetosVoladores) {
			try {
				System.out.println("preparando siguiente despegue...\n");
				iVolador.encender();
				Thread.sleep(1000);
				iVolador.despegar();
				Thread.sleep(2000);
				iVolador.acelerar();
				Thread.sleep(3000);
				System.out.println("\nobjeto en orbita...\n\n");
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}

		// aterrizamos a nuestros objetos voladores en espacio aereo
		for (IVolador iVolador : objetosVoladores) {
			try {
				System.out.println("preparando aterrizaje ...\n");
				iVolador.desacelerar();
				Thread.sleep(1000);
				iVolador.aterrizar();
				Thread.sleep(2000);
				iVolador.apagar();
				Thread.sleep(3000);
				System.out.println("\nobjeto estacionado...\n\n");
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
}