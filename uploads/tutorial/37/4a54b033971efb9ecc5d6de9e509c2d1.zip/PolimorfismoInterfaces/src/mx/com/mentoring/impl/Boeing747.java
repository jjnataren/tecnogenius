package mx.com.mentoring.impl;

import mx.com.mentoring.IVolador;

public class Boeing747 implements IVolador {

	private void iniciarRodaje() {
		System.out.println(" iniciando desplazamiento en tierra...");
	}

	private void encenderMotores() {
		System.out.println(" motores 1,2,3 y 4 encendidos");
	}

	private void recogerTrenAterrizaje() {
		System.out.println(" repliegue de tren de aterrizaje...");
	}

	private void desplegarTrenAterrizaje() {
		System.out.println(". . . desplegando tren de aterrizaje");
	}

	private void detenerRodaje() {
		System.out.println(". . . disminuyendo velocidad de tren de aterrizaje");
	}

	private void apagarMotores() {
		System.out.println(". . . apagando motores 1,2,3 y 4");
	}

	public void aterrizar() {
		System.out.println(". . . avion acercandose a tierra");
		desplegarTrenAterrizaje();
		apagarMotores();
		detenerRodaje();
	}

	public void despegar() {
		iniciarRodaje();
		encenderMotores();
		recogerTrenAterrizaje();
	}

	public void acelerar() {
		System.out.println("  acelerar a una velocidad de 20 nudos por segundo...");
	}

	public void desacelerar() {
		System.out.println(" . . .disminuyendo velocidad de motores 1,2,3 y 4");
	}

	public void encender() {
		System.out.println("iniciando encendido de Boeing 747...");		
	}

	public void apagar() {
		System.out.println(". . . apagando Boein747");
	}

}