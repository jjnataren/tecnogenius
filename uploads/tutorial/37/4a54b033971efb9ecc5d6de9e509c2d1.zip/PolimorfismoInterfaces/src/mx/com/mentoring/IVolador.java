package mx.com.mentoring;

public interface IVolador {
	public void aterrizar();
	public void despegar();
	public void acelerar();
	public void desacelerar();
	public void encender();
	public void apagar();
}