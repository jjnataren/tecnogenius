package mx.com.mentoring.impl;

import mx.com.mentoring.IVolador;

public class Helicoptero implements IVolador {

	private void iniciarRotorPrincipal() {
		System.out.println(" rotor principal encendido...");
	}

	private void iniciarRotorTrasero() {
		System.out.println(" rotor trasero encendido...");
	}

	private void detenerRotorPrincipal() {
		System.out.println(" . . . rotor principal apagado");
	}

	private void detenerRotorTrasero() {
		System.out.println(" . . . rotor trasero apagado");
	}

	public void aterrizar() {
		System.out.println(". . . helicoptero en tierra");
		detenerRotorPrincipal();
		detenerRotorTrasero();
	}

	public void despegar() {
		iniciarRotorPrincipal();
		iniciarRotorTrasero();
	}

	public void acelerar() {
		System.out.println(" aumentando velocidada a 20 nudos...");
	}

	public void desacelerar() {
		System.out.println(" . . .disminuyeno velocidad de rotor principal");
	}

	public void encender() {
		System.out.println("iniciando encendido de helicoptero...");
	}

	public void apagar() {
		System.out.println(" . . . apagando helicoptero");
	}
}