public class TestIterarArray {

	/**
	 * m�todo publico y estatico main que indica que esta clase 
	 * puede ser ejecutada sin la necesidad de crear un objeto
	 */
	public static void main(String[] args) {
		
		// declaramos un arreglo llamado cuentas que almacenara objetos de tipo entero (int)
		int[] cuentas;
		
		// inicializamos el arreglo indicando que contendra 3 elementos
		cuentas = new int[3];
		
		// llenamos nuestro arreglo con tres numeros de cuenta
		cuentas[0] = 90324532;
		cuentas[1] = 30855556;
		cuentas[2] = 24251013;
		
		//iteramos sobre el arreglo y enviamos a consola cada uno de los elementos existentes en el arreglo
		for (int i = 0; i <cuentas.length; i++) {
			System.out.println(cuentas[i]);
		}
	}
}