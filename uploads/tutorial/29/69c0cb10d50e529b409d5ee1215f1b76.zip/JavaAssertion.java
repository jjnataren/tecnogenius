public class JavaAssertion {

	public static void main(String[] args) {
		
		int x=0;

		// primera forma de implementar un assertion no envia detalle a la consola
		/*
		assert x>0;
		*/
		// segunda forma de implementar un assertion permite agregar detalle adicional para que se envie a la consola
		
		assert(x>0):"x no es mayor a 0, esta afirmacion no se cumple!";
	}
}