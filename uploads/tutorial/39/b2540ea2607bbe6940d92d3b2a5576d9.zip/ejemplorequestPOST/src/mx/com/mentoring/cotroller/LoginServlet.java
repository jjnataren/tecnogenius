package mx.com.mentoring.cotroller;

import java.io.IOException;
import java.util.Map;
import java.util.Map.Entry;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public LoginServlet() {
	}

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// obtenemos la informacion que viene en la
		// peticion realizada desde el formulario
		Map<String, String[]> parametros = request.getParameterMap();

		for (Entry<String, String[]> entry : parametros.entrySet()) {
			System.out.println("parametro: " + entry.getKey());
			System.out.println("valor del parametro: " + entry.getValue()[0]);

			/*
			 * ponemos en el request el atributo "nombre" y su valor.
			 */
			request.setAttribute(entry.getKey(), entry.getValue()[0]);
		}

		RequestDispatcher dispatcher = request
				.getRequestDispatcher("bienvenido.jsp");

		dispatcher.forward(request, response);
	}
}